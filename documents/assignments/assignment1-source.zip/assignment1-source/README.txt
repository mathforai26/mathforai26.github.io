Compile with: latexmk -pdf -interaction=nonstopmode -halt-on-error document.tex
Keep the supplied lecture PDFs and auxiliary files for external references.
